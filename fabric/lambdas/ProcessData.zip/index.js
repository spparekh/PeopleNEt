//'use strict';
//console.log('Loading function');


//exports.handler = (event, context, callback) => {
//    /* Process the list of records and transform them */

//    const output = event.records.map((record) => ({
//        /* This transformation is the "identity" transformation, the data is left intact */
//        recordId: record.recordId,        
//        result: 'Ok',
//        data: record.data,
//    }));
//    console.log(`Processing completed.  Successful records ${output.length}.`);
//    callback(null, { records: output });
//};

'use strict';
console.log('Loading function');

/* Syslog format parser */
//const parser = '^((?:\\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?' +
//    '|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\b\\s+(?:(?:0[1-9])|(?:[12][0-9])|(?:3[01])|[1-9])\\s+' +
//    '(?:(?:2[0123]|[01]?[0-9]):(?:[0-5][0-9]):(?:(?:[0-5]?[0-9]|60)(?:[:\\.,][0-9]+)?)))) (?:<(?:[0-9]+).(?:[0-9]+)> ' +
//    ')?((?:[a-zA-Z0-9._-]+)) ([\\w\\._/%-]+)(?:\\[((?:[1-9][0-9]*))\\])?: (.*)';

exports.handler = (event, context, callback) => {
    let success = 0; // Number of valid entries found
    let failure = 0; // Number of invalid entries found
    //console.log("Data" + event.records.data);
    /* Process the list of records and transform them */
    var json2csv = require("json2csv");
    const output = event.records.map((record) => {
        // Kinesis data is base64 encoded so decode here
        console.log("Record ID : "+ record.recordId);
        const payload = new Buffer(record.data, 'base64').toString('ascii');
        console.log('Decoded payload:', payload);
        var jsonObj = JSON.parse(payload);
        console.log('Sequence ', jsonObj.sequence);
        jsonObj.sequence = jsonObj.sequence + 100
        //var fields = ["sequence", "breadCrumbDateTime", "perfromxFuel", "location", "reason", "performxOdometer", "sentDateTime", "ignition", "type", "version", "gpsBcDistance", "driverLoginId2", "driverLoginId1", "ambientTemp", "performxPTO", "locationFormat", "longitude", "systemId", "vid", "trailerId1", "driverStatus2", "signalStrength", "did1", "did2", "gpsOdometer", "speed", "trailerId2", "pacosTripId", "performxSpeed", "vehicleNumber", "driverStatus1", "performxIdle", "fuelLevel1", "gpsAntenna", "fuelLevel2", "dsn", "gpsQuality", "latitude", "companyId", "heading"];
        //console.log('Fields :' + csvresult);
        var csvresult = json2csv({ data: jsonObj, hasCSVColumnTitle: false, del: "|"});
        csvresult = csvresult + '\r\n';
        //, hasCSVColumnTitle: false, del: "|"
        console.log('CSV result' + csvresult);
            success++;
            return {
                recordId: record.recordId,
                result: 'Ok',
                data: new Buffer(csvresult).toString('base64'),
            };
        //} else {
            /* Failed event, notify the error and leave the record intact */
          //  failure++;
            //return {
            //    recordId: record.recordId,
            //    result: 'ProcessingFailed',
            //    data: record.data,
            //};
        //}
    });
    console.log(`Processing completed.  Successful records ${success}, Failed records ${failure}.`);
    callback(null, { records: output });
};

