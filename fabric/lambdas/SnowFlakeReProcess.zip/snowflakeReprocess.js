﻿exports.snowflakeReprocess =function (data1) {
    console.log("Inside Snowflake process");
    var cur_reexid = process.env.reExId;
    var cur_status = process.env.progStatus;

    var new_ID = parseInt(cur_reexid) + 1;
    process.env.reExId = new_ID;
    var copytoDBReprogressEvent = require('./copytoDBReprogressEvent.js');
    copytoDBReprogressEvent.copytoDB_reprogress(cur_status, cur_reexid, data1);
    var Sqlquery = data1.CopyCommand.S;
    var mergeFile = data1.S3filepath.S;
    var parentID = data1.ExecutionCopytoDBID.N;
    var reprocessSnowflake = require('./snowflakeCopyProcess.js');
    reprocessSnowflake.reprocess_executeSql(Sqlquery, mergeFile, cur_reexid, parentID);
    console.log("Reprocess cur_status : ", cur_status);


}
