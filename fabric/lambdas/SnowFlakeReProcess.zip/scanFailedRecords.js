﻿

exports.scanFailedRecords=function () {

    var AWS = require("aws-sdk");
    AWS.config.update({
        region: process.env.region
    });

    var table = process.env.tableNameCopy;
    var params = {
        TableName: table,
        ScanFilter: {
            "Status1": { "AttributeValueList": [{ "S": process.env.failStatus }], "ComparisonOperator": "CONTAINS" },
            "Retry": { "AttributeValueList": [{ "N": process.env.retryFinalValue }], "ComparisonOperator": "LE" },
            "Reprocessing": { "AttributeValueList": [{ "N": process.env.reProcessingParentValue }], "ComparisonOperator": "EQ" }
        },
    };

    var dynamo = new AWS.DynamoDB();

    console.log("Scanning COPYTODB table.");

    dynamo.scan(params, function (err, data) {
        if (err) {
            console.log("Error scanning copytodb tablee", err);

        } else {

            console.log(data.Items);
            data.Items.forEach(function (data1) {
                console.log("Execution ID", data1.ExecutionCopytoDBID);
                console.log("Status", data1.Status1);
                var exid = data1.ExecutionCopytoDBID;
                var snowflakeReprocessData = require('./snowflakeReprocess.js');
                snowflakeReprocessData.snowflakeReprocess(data1);

            });

        }
    });

}







