﻿exports.reprocess_executeSql =function (Sqlquery, mergeFile, executionCopyToDBID, parentID) {

    var snowflake = require('snowflake-sdk');
    var table = process.env.tableNameCopy;
    var connection = snowflake.createConnection({
        account: process.env.snowflakeAccount,
        username: process.env.snowflakeUserName,
        password: process.env.snowflakePassword,
        warehouse: process.env.snowflakeWarehouse,
        database: process.env.snowflakeDatabase,
        schema: process.env.snowflakeSchema
    });
    connection.connect(function (err, conn) {
        if (err) {
            console.error('Unable to connect: ' + err.message);

        } else {
            console.log('Successfully connected as id: ' + connection.getId());

        }
    });


    connection.execute({
        sqlText: Sqlquery,
        complete: function (err, stmt, rows) {
            if (err) {
                var cur_status = process.env.failStatus;
                var total_row_processed = 0;
                var endtime = new Date();
                var insertError = require('./errorHandling.js');
                insertError.update_error(err, executionCopyToDBID, table);
                var updateProgress = require('./copytoDbProgressUpdate.js');
                updateProgress.copytoDB_progress_update(cur_status, executionCopyToDBID, total_row_processed, Number(endtime));

                console.error('Failed to execute statement due to the following error: ' + err.message);

            } else {
                var cur_status = process.env.successStatus;
                var endtime = new Date();
                console.log('success in copy command');
                var metadatainfo_row = JSON.stringify(rows[0]);
                var metadatainfo_obj = JSON.parse(metadatainfo_row);
                var total_row_processed = metadatainfo_obj.rows_parsed;
                var updateParentID = require('./updateParentStatus.js');
                updateParentID.update_parent_status(cur_status, parentID);
                var updateProgress = require('./copytoDbProgressUpdate.js');
                updateProgress.copytoDB_progress_update(cur_status, executionCopyToDBID, parseInt(total_row_processed), Number(endtime));

            }
        }
    });

}
