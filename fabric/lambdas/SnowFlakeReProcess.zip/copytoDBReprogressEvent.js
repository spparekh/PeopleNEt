﻿exports.copytoDB_reprogress = function (cur_status, executionCopyToDBID, record) {
    var AWS = require("aws-sdk");
    AWS.config.update({
        region: process.env.region
    });

    //Insert item
    var dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

    var table = process.env.tableNameCopy;

    var time1 = new Date();
    var numeric_time = Number(time1);
    var string_starttime = String(numeric_time);
    var bucketname = record.bucketname.S;
    var S3filepath = record.S3filepath.S;

    var eventinfo = record.EventInfo.S;
    var eventTime = record.EventTime.S;
    var eventName = record.EventName.S;
    var Reprocessing = process.env.reProcessingChildValue;
    var Sqlquery = record.CopyCommand.S;
    console.log("Adding a new item...");
    var Tablename = record.Tablename.S;
    var parentexid = record.ExecutionCopytoDBID.N;
    var retry = record.Retry.N;
    retry = parseInt(retry) + 1;
    var item =
        {
            "ExecutionCopytoDBID": { "N": executionCopyToDBID },
            "Tablename": { "S": Tablename },
            "Status1": { "S": cur_status },
            "StartTime": { "S": string_starttime },
            "S3filepath": { "S": S3filepath },
            "bucketname": { "S": bucketname },
            "EventInfo": { "S": eventinfo },
            "EventTime": { "S": eventTime },
            "EventName": { "S": eventName },
            "CopyCommand": { "S": Sqlquery },
            "Reprocessing": { "N": Reprocessing },
            "ParentExID": { "N": parentexid }
        }

    dynamodb.putItem({ TableName: table, Item: item }, function (err, data) {
        if (err) {
            console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
            console.log("eRROR code:", err.code);
            console.log("eRROR message:", err.message);
            var insertError = require('./errorHandling.js');
            insertError.update_error(err, executionCopyToDBID, table);
        } else {
            console.log("Added item:", JSON.stringify(data, null, 2));
            var retryCount = require('./updateRetryCount.js');
            retryCount.update_retry_count(retry, parentexid);
        }
    });
    console.log("Items are succesfully ingested in table ..................");
}