﻿//update error status in case of any failure

exports.update_error =function (err, executionCopyToDBID, table) {
    var AWS = require("aws-sdk");
    AWS.config.update({
        region: process.env.region
    });

    var dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
    var error_code = err.code;
    var error_message = err.message;
    var cur_status = process.env.failStatus;
    var params = {
        TableName: table,
        Key: {
            "Reprocessing": { "N": process.env.reProcessingChildValue },
            "ExecutionCopytoDBID": { "N": executionCopyToDBID }
        },
        UpdateExpression: "set Status1 = :S1 ,ErrorCode = :C,ErrorMessage = :M",
        ExpressionAttributeValues: {
            ":S1": { "S": cur_status },
            ":C": { "N": error_code },
            ":M": { "S": error_message }
        },
        ReturnValues: "UPDATED_NEW"
    };
    console.log("Updating the item...");
    dynamodb.updateItem(params, function (err, data) {
        if (err) {
            console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
            // update_error(err, executionCopyToDBID, table);
        } else {
            console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
        }
    });


}
