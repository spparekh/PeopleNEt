﻿//update item - copytodb dynamodb update progress 
exports.copytoDB_progress_update =function (cur_status, executionCopyToDBID, total_row_processed, endtime) {

    var AWS = require("aws-sdk");
    AWS.config.update({
        region: process.env.region
    });

    var dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
    var table = process.env.tableNameCopy;
    var rows = String(total_row_processed);
    var string_endtime = String(endtime);
    var params = {
        TableName: table,
        Key: {
            "Reprocessing": { "N": process.env.reProcessingChildValue },
            "ExecutionCopytoDBID": { "N": executionCopyToDBID }
        },
        UpdateExpression: "set Status1 = :S1 ,TotalNoofRecords = :R,EndTime = :E",
        ExpressionAttributeValues: {
            ":S1": { "S": cur_status },
            ":R": { "N": rows },
            ":E": { "N": string_endtime }
        },
        ReturnValues: "UPDATED_NEW"
    };
    console.log("Updating the item...");
    dynamodb.updateItem(params, function (err, data) {
        if (err) {
            console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
            var errorUpdate = require('./errorHandling.js');
            errorUpdate.update_error(err, executionCopyToDBID, table);
        } else {
            console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
        }
    });


}
