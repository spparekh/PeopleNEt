﻿

exports.update_retry_count =function (retry, parentexid) {

    var AWS = require("aws-sdk");
    AWS.config.update({
        region: process.env.region
    });

    var string_retry = String(retry);

    var dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
    var table = process.env.tableNameCopy;

    var params = {
        TableName: table,
        Key: {
            "Reprocessing": { "N": process.env.reProcessingParentValue },
            "ExecutionCopytoDBID": { "N": parentexid }
        },
        UpdateExpression: "set Retry = :R",
        ExpressionAttributeValues: {
            ":R": { "N": string_retry }
        },
        ReturnValues: "UPDATED_NEW"
    };
    console.log("Updating the item...");
    dynamodb.updateItem(params, function (err, data) {
        if (err) {
            console.error("Unable to retrycount. Error JSON:", JSON.stringify(err, null, 2));
            var errorUpdate = require('./errorHandling.js');
            errorUpdate.update_error(err, parentexid, table);
        } else {
            console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
        }
    });
}

