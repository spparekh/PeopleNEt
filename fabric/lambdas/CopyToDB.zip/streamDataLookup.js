﻿// Get stream details from dynamodb table -"Streamsetup"

exports.get_metatdata_info = function (streamtype, bucketpath, callback) {
    var AWS = require("aws-sdk");
    AWS.config.update({
        region: process.env.region
    });

    var dynamodb1 = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
    var table1 = process.env.tableNameStreamDetails;
    var StreamName = streamtype;
    var params = {
        TableName: table1,
        Key: {
            "StreamName": { "S": StreamName }
        }
    };
    dynamodb1.getItem(params, function (err, data) {

        if (err) {
            console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));


        } else {
            var metadatainfo_json = JSON.stringify(data);
            var metadatainfo_obj = JSON.parse(metadatainfo_json);
           
            console.log("Get item succeeded", JSON.stringify(data));
            callback(metadatainfo_obj);
        }
    });

}