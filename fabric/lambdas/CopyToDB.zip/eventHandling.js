﻿//function to insert item - progress status in copytodb dynamodb table

exports.copytoDB_progress =function (cur_status, Tablename, executionCopyToDBID, recordobj, Sqlquery) {
    var AWS = require("aws-sdk");
    AWS.config.update({
        region: process.env.region
    });

    //Insert item
    var dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

    var table = process.env.tableNameCopy;

    var time1 = new Date();
    var numeric_time = Number(time1);
    var string_starttime = String(numeric_time);
    var bucketname = recordobj.s3.bucket.name;
    var object_key = recordobj.s3.object.key;
    var object_size = recordobj.s3.object.size;

    var streamtype = object_key.split("/", 1)[0];

    var bucketpath = object_key.split("/", 1)[0];
    var eventinfo = JSON.stringify(recordobj);
    var eventTime = recordobj.eventTime;
    var eventName = recordobj.eventName;
    var Reprocessing = process.env.reProcessingParentValue;
    var Retry = process.env.retryIntialValue;
    console.log("Adding a new item...");
    var item =
        {
            "ExecutionCopytoDBID": { "N": executionCopyToDBID },
            "Tablename": { "S": Tablename },
            "Status1": { "S": cur_status },
            "StartTime": { "S": string_starttime },
            "S3filepath": { "S": object_key },
            "bucketname": { "S": bucketname },
            "EventInfo": { "S": eventinfo },
            "EventTime": { "S": eventTime },
            "EventName": { "S": eventName },
            "CopyCommand": { "S": Sqlquery },
            "Reprocessing": { "N": Reprocessing },
            "Retry": { "N": Retry }
        }

    dynamodb.putItem({ TableName: table, Item: item }, function (err, data) {
        if (err) {
            console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));


        } else {
            console.log("Added item:", JSON.stringify(data, null, 2));
        }
    });
    console.log("Items are succesfully ingested in table ..................");
}
