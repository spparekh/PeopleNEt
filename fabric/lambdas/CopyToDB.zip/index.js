﻿console.log('Loading');

exports.handler = function (event, context) {

    if (event != null) {
        console.log('event = ' + JSON.stringify(event));
    }
    else {
        console.log('No event object');

    }
    
    
    // call method to get S3 put event details
    var recordobj = geteventdetails(event);
    var bucketname = recordobj.s3.bucket.name;
    var object_key = recordobj.s3.object.key;
    var object_size = recordobj.s3.object.size;

    var streamtype = object_key.split("/", 1)[0];

    var bucketpath = object_key.split("/", 1)[0];
    var streamDetails = require('./streamDataLookup.js');
    streamDetails.get_metatdata_info(streamtype, bucketpath, function (metadatainfo_obj) {
        var cur_status = process.env.progStatus;
        var Tablename = metadatainfo_obj.Item.SnowflakeTable.S;

        var Sqlquery_withoutfile = metadatainfo_obj.Item.SQLquery.S;
        var Sqlquery = generate_SQLquery(Sqlquery_withoutfile, bucketname, object_key);

        var executionCopyToDBID = generate_executionID();
        var mergeFile = object_key;
        var eventsRecord = require('./eventHandling.js');
        eventsRecord.copytoDB_progress(cur_status, Tablename, executionCopyToDBID, recordobj, Sqlquery);
        var snowFlake = require('./snowflakeCopyProcess.js');
        snowFlake.executeSql(Sqlquery, mergeFile, executionCopyToDBID);
   
    }); 

};

// Get event details of S3 put event
function geteventdetails(event) {
    var s3_event = JSON.stringify(event);
    var jsonogbj = JSON.parse(s3_event);
    var record = JSON.stringify(jsonogbj.Records[0]);
    var recordobj = JSON.parse(record);
    console.log('event = ' + JSON.stringify(jsonogbj));
    return recordobj;
}


// funstion to generate executionID

function generate_executionID() {
    var cur_ID = process.env.zeroExecutionID;
    if (isNaN(process.env.exID)) {
        cur_ID = process.env.IntitalExecutionID;
        var new_ID = parseInt(cur_ID) + 1;
        process.env.exID = new_ID;
    }
    else {
        cur_ID = process.env.exID;
        var new_ID = parseInt(cur_ID) + 1;
        process.env.exID = new_ID;

    }

    return cur_ID;
}


// function to generate current time and 
function getdatetime() {

    var d = new Date();
    console.log("startDate: ", Number(d));
    // var dt = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds() + ":" + d.getMilliseconds() + " " + d.getFullYear() + "/" + d.getMonth() + "/" + d.getDate();
    // console.log(dt);
    return Number(d);

}



// function to update the current event filename in the copy command 
function generate_SQLquery(Sqlquery_withoutfile, bucketname, object_key) {
       var bucketname_file = bucketname.concat("/", object_key);
       var Sqlquery = Sqlquery_withoutfile.replace(process.env.replaceKeyword, bucketname_file);
       return Sqlquery;
}